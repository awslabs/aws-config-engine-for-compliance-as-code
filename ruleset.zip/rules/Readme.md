Those rules are a mix of custom and managed Config Rules. 

Find more examples and use cases: https://github.com/awslabs/aws-config-rules/